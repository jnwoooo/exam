﻿<#
.SYNOPSIS
  C++ 버전 업데이트 대응 자동화의 단일 진입 명령.
.DESCRIPTION
  같은 폴더의 vupdate.exe (없으면 python vupdate.py) 를 호출한다.
  처리는 전부 vupdate 가 한다. 이 스크립트는 인자를 넘기고 종료 코드를 돌려줄 뿐이다.
  종료 코드: 0 완료 / 1 완료(수동 검토 있음) / 2 단계 실패 / 3 입력 오류
.EXAMPLE
  .\Invoke-VersionUpdate.ps1 -Package D:\src\PKG_A -FromVs 2008 -ToVs 2022
.EXAMPLE
  .\Invoke-VersionUpdate.ps1 -Package D:\src\PKG_A -EnvProfile vs2008_to_vs2022 -Request PKG_A
.EXAMPLE
  .\Invoke-VersionUpdate.ps1 -Resume D:\work\runs\PKG_A\20261124_101500
#>
param(
    [string]$Package,
    [string]$EnvProfile,
    [string]$FromVs,
    [string]$ToVs,
    [string]$CppStandard,
    [string]$Request,
    [string]$LlmEndpoint,
    [int]$MaxParallel = 0,
    [string]$Out,
    [string]$UntilStage,
    [string]$Resume,
    [switch]$DryRun,
    [switch]$NoCompile
)

[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$exe = Join-Path $here "vupdate.exe"
$py = Join-Path $here "vupdate.py"

$a = @("--console-encoding", "utf-8", "run")
if ($Resume) {
    $a += @("--resume", $Resume)
} else {
    if (-not $Package) { Write-Host "오류: -Package 로 대상 패키지 폴더를 지정하세요."; exit 3 }
    $a += @("--package", $Package)
}
if ($EnvProfile)  { $a += @("--profile", $EnvProfile) }
if ($FromVs)      { $a += @("--from-vs", $FromVs) }
if ($ToVs)        { $a += @("--to-vs", $ToVs) }
if ($CppStandard) { $a += @("--cpp-standard", $CppStandard) }
if ($Request)     { $a += @("--request", $Request) }
if ($LlmEndpoint) { $a += @("--llm-endpoint", $LlmEndpoint) }
if ($MaxParallel -gt 0) { $a += @("--max-parallel", "$MaxParallel") }
if ($Out)         { $a += @("--out", $Out) }
if ($UntilStage)  { $a += @("--until", $UntilStage) }
if ($DryRun)      { $a += "--dry-run" }
if ($NoCompile)   { $a += "--no-compile" }

if (Test-Path $exe) {
    & $exe @a
} elseif (Test-Path $py) {
    & python $py @a
} else {
    Write-Host "오류: vupdate.exe 또는 vupdate.py 가 이 스크립트와 같은 폴더에 없습니다."
    exit 3
}
exit $LASTEXITCODE
